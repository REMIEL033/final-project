%%%FINAL PPI FORCAST

%%%%%%1.DATA PREPARATION
infl = readtable('infl.csv');
inflnor=sortrows(infl,'month');
targetCPI = inflnor.CPI;
targetCPI = array2table(targetCPI, 'VariableNames', {'CPI'});
targetPPI = inflnor.PPI;
targetPPI = array2table(targetPPI, 'VariableNames', {'PPI'});

%%%PPI Forcast
lag = 2;
inflnor= removevars(inflnor, {'month', 'PPI'});
inflnor = lagmatrix(inflnor, 1:lag);%lag
inflnor = removevars(inflnor, 'TLag');
%normalize
inflnor = normalize(inflnor);
PPI_lagged = lagmatrix(targetPPI, 1:lag);%lag
X = horzcat(PPI_lagged,inflnor);
X = removevars(X, 'TLag');

%Train and Test
training_X = X(1:168, :);
testing_X = X(169:end, :);
training_PPI = targetPPI(1:168, : );
testing_PPI = targetPPI(169:end, : );
training_X = table2array(training_X);
training_PPI = table2array(training_PPI);
testing_X = table2array(testing_X);
testing_PPI = table2array(testing_PPI);

%lasso
while true
[B, FitInfo] = lasso(training_X, training_PPI, 'CV', 10, "Alpha",0.2,"Lambda",0.01);

% fit linear model with selected predictors

lassoModel = fitlm(training_X(:,FitInfo.Index1SE), training_PPI);
X_train_lasso = training_X(:,FitInfo.Index1SE);
X_test_lasso = testing_X(:,FitInfo.Index1SE);



% LM
mdl = fitlm(X_train_lasso,training_PPI);
PPI_pred = predict(mdl,X_test_lasso);

% Assess
rmse = sqrt(mean((testing_PPI - PPI_pred).^2));
SSres = sum((testing_PPI - PPI_pred).^2); % sum of squared residuals on test set
SStot = sum((testing_PPI - mean(testing_PPI)).^2); % total sum of squares on test set
r2 = 1 - SSres/SStot; % out-of-sample R-squared

  if r2 > 0.7
        break; % 如果R2大于 0.7，就跳出循环
    end
end
fprintf('\n');
fprintf('LASSO PPI\n')
fprintf('RMSE: %f\n',rmse);
fprintf('R^2: %f\n',r2);


%%%%%3. PCA and RF
% Perform Principal Component Analysis (PCA) for feature selection
[coeff, ~, ~, ~, explained] = pca(training_X);
num_components = find(cumsum(explained) >= 60, 1);
X_train_pca = training_X * coeff(:, 1:num_components);
X_test_pca = testing_X * coeff(:, 1:num_components);

% Random Forest Regression
mdl = TreeBagger(120, X_train_pca, training_PPI);
PPI_pred = predict(mdl, X_test_pca);
PPI_pred = str2double(PPI_pred);

% Assess
rmse = sqrt(mean((testing_PPI - PPI_pred).^2));
SSres = sum((testing_PPI - PPI_pred).^2); % sum of squared residuals on test set
SStot = sum((testing_PPI - mean(testing_PPI)).^2); % total sum of squares on test set
r2 = 1 - SSres / SStot; % out-of-sample R-squared
fprintf('\n')
fprintf('PCA+RF PPI\n');
fprintf('RMSE: %f\n', rmse);
fprintf('R^2: %f\n', r2);


%%%%%3. GB
% Gradient Boosting Regression model construction
numTrees = 150; % Number of trees
learningRate = 0.1; % Learning rate
tree = templateTree('MaxNumSplits', 10); % Decision tree template
gbt = fitensemble(training_X, training_PPI, 'LSBoost', numTrees, tree, 'LearnRate', learningRate);

% Prediction
PPI_pred = predict(gbt, testing_X);

% Evaluation
rmse = sqrt(mean((testing_PPI - PPI_pred).^2));
SSres = sum((testing_PPI - PPI_pred).^2);
SStot = sum((testing_PPI - mean(testing_PPI)).^2);
r2 = 1 - SSres / SStot;
fprintf('\n')
fprintf('GB PPI\n');
fprintf('RMSE: %f\n', rmse);
fprintf('R^2: %f\n', r2);



















