%%%FINAL CPI

%%%%%%1.DATA PREPARATION
infl = readtable('infl.csv');
inflnor=sortrows(infl,'month');
targetCPI = inflnor.CPI;
targetCPI = array2table(targetCPI, 'VariableNames', {'CPI'});
targetPPI = inflnor.PPI;
targetPPI = array2table(targetPPI, 'VariableNames', {'PPI'});

%%%CPI Forcast
lag = 6;
inflnor= removevars(inflnor, {'month', 'CPI'});
inflnor = lagmatrix(inflnor, 1:lag);
inflnor = removevars(inflnor, 'TLag');

%normalize
inflnor = normalize(inflnor);



CPI_lagged = lagmatrix(targetCPI, 1:lag);
X = horzcat(CPI_lagged,inflnor);
X = removevars(X, 'TLag');

%Train and Test
training_X = X(1:138, :);
testing_X = X(139:end, :);
training_CPI = targetCPI(1:138, : );
testing_CPI = targetCPI(139:end, : );
training_X = table2array(training_X);
training_CPI = table2array(training_CPI);
testing_X = table2array(testing_X);
testing_CPI = table2array(testing_CPI);

%%%%%2. LASSO
while true
[B, FitInfo] = lasso(training_X, training_CPI, 'CV', 10,"lambda",0.01,"Alpha",0.2);

% fit linear model with selected predictors
%lassoPlot(B,FitInfo,'PlotType','Lambda','XScale','log');
lassoModel = fitlm(training_X(:,FitInfo.Index1SE), training_CPI);
X_train_lasso = training_X(:,FitInfo.Index1SE);
X_test_lasso = testing_X(:,FitInfo.Index1SE);


% LM
mdl = fitlm(X_train_lasso,training_CPI);
CPI_pred = predict(mdl,X_test_lasso);

% Assess
rmse = sqrt(mean((testing_CPI - CPI_pred).^2));
SSres = sum((testing_CPI - CPI_pred).^2); % sum of squared residuals on test set
SStot = sum((testing_CPI - mean(testing_CPI)).^2); % total sum of squares on test set
r2 = 1 - SSres/SStot; % out-of-sample R-squared

  if r2 > 0.3
        break; % 如果r2大于 0.3，就跳出循环
    end
end
fprintf('\n')
fprintf('LASSO CPI\n');
fprintf('RMSE: %f\n',rmse);
fprintf('R^2: %f\n',r2);


%%%%%3. PCA and RF
% Perform Principal Component Analysis (PCA) for feature selection
[coeff, ~, ~, ~, explained] = pca(training_X);
num_components = find(cumsum(explained) >= 60, 1);
X_train_pca = training_X * coeff(:, 1:num_components);
X_test_pca = testing_X * coeff(:, 1:num_components);

% Random Forest Regression
mdl = TreeBagger(120, X_train_pca, training_CPI);
CPI_pred = predict(mdl, X_test_pca);
CPI_pred = str2double(CPI_pred);

% Assess
rmse = sqrt(mean((testing_CPI - CPI_pred).^2));
SSres = sum((testing_CPI - CPI_pred).^2); % sum of squared residuals on test set
SStot = sum((testing_CPI - mean(testing_CPI)).^2); % total sum of squares on test set
r2 = 1 - SSres / SStot; % out-of-sample R-squared
fprintf('\n')
fprintf('PCA+RF CPI\n');
fprintf('RMSE: %f\n', rmse);
fprintf('R^2: %f\n', r2);


%%%%%3. GB
% Gradient Boosting Regression model construction
numTrees = 150; % Number of trees
learningRate = 0.1; % Learning rate
tree = templateTree('MaxNumSplits', 10); % Decision tree template
gbt = fitensemble(training_X, training_CPI, 'LSBoost', numTrees, tree, 'LearnRate', learningRate);

% Prediction
CPI_pred = predict(gbt, testing_X);

% Evaluation
rmse = sqrt(mean((testing_CPI - CPI_pred).^2));
SSres = sum((testing_CPI - CPI_pred).^2);
SStot = sum((testing_CPI - mean(testing_CPI)).^2);
r2 = 1 - SSres / SStot;
fprintf('\n')
fprintf('GB CPI\n');
fprintf('RMSE: %f\n', rmse);
fprintf('R^2: %f\n', r2);

